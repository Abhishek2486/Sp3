package com.Spring.SpringBoot.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.Spring.SpringBoot.entity.Movie;
@Repository
public interface MovieRepository extends CrudRepository<Movie, Integer>{

}
