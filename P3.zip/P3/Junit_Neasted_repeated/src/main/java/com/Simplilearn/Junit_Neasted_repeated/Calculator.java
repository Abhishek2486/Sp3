package com.Simplilearn.Junit_Neasted_repeated;

public class Calculator {
int calculate(int a,int b) {
	return a + b;
}
}
