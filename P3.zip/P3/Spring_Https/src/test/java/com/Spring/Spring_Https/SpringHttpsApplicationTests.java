package com.Spring.Spring_Https;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
