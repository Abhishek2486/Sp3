package com.Simplilearn.Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSetupApplicationTests {

	@Test
	void contextLoads() {
	}

}
