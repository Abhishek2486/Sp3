package com.Spring.eventhandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEventHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
