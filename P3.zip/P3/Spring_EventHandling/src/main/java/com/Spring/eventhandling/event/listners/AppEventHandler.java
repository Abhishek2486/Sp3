package com.Spring.eventhandling.event.listners;

import org.springframework.context.event.ContextStartedEvent;
import org.springframework.context.event.ContextStoppedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class AppEventHandler {
@EventListener
	public static void onApplicationStartEvent(ContextStartedEvent cse) {
	System.out.println("context started event recived");

}
@EventListener
public static void onApplicationStopEvent(ContextStoppedEvent cse) {
	System.out.println("context stoped event recived");
	
}
}
