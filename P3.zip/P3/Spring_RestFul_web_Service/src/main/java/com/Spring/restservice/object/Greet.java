package com.Spring.restservice.object;

public class Greet {
private String name;
private String message;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
}
