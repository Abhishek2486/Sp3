package com.Simplilearn.jdbc.model;

public class Eproduct {
	private int ID;
	private String Pname;
private double  Price;
public int getID() {
	return ID;
}
public void setID(int iD) {
	ID = iD;
}
public String getPname() {
	return Pname;
}
public void setPname(String pname) {
	Pname = pname;
}
public double getPrice() {
	return Price;
}
public void setPrice(double price) {
	Price = price;
}
}