package com.Simplilearn.jdbc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Simplilearn.jdbc.Dao.EproductDao;
import com.Simplilearn.jdbc.model.Eproduct;

@Controller
public class EproductController {
	@Autowired
	EproductDao eproductDao;

	@GetMapping("/listProducts")
	public String listProducts(Model model) {

		List<Eproduct> products = eproductDao.getproducts();

		model.addAttribute("products", products);

		return "listProducts";
	}
}
