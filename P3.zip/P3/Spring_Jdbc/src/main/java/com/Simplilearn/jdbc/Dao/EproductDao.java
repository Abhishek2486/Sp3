package com.Simplilearn.jdbc.Dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.Simplilearn.jdbc.model.Eproduct;
@Repository
public class EproductDao {
@Autowired
JdbcTemplate jdbctemplate;

public List<Eproduct> getproducts() {

	return jdbctemplate.query("select * from eproduct", new RowMapper<Eproduct>() {

		@Override
		public Eproduct mapRow(ResultSet rs, int rowNum) throws SQLException {

			Eproduct ep = new Eproduct();
			ep.setID(rs.getInt(1));
			ep.setPname(rs.getString(2));
			ep.setPrice(rs.getDouble(3));

			return ep;
		}

	});
}
}
